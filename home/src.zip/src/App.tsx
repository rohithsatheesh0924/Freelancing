import HomePage from "./main/pages/HomePage/home-page";

function App() {
  return <HomePage />;
}

export default App;
