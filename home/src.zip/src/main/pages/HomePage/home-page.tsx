import React, { useState } from "react";
import "./home-page.css";
import NavBar from "./components/nav-bar/nav_bar";
import SearchContainer from "./components/search-container/search_container";
import TrendingCarousel from "./components/explore-tab/trending-freelancer--carousel/trending_freelancer_carousel";

interface HomePageProps {}

const HomePage: React.FC<HomePageProps> = () => {
  // controlling the tab switching
  const [activeTab, setActiveTab] = useState("tab-1");
  return (
    //
    // wrapper to wrap all the content of main column margin
    //
    <div className="my-body">
      <div className="wrapper">
        {/* navigation bar component */}
        <NavBar
          gmail={gmail}
          notificationBadge={notificationBadge}
          profileUrl={profileUrl}
          userName={userName}
        />
      </div>
      <div className="horizontal-divider"></div>

      <div className="wrapper">
        {/* Search container component */}
        <SearchContainer />
        {/* Controller button for the tab management */}
        <div className="tab-switch-buttons">
          <button
            className={
              activeTab === "tab-1"
                ? "tab-switch-button-active"
                : "tab-switch-button"
            }
            onClick={() => setActiveTab("tab-1")}
          >
            Explore
          </button>
          <button
            className={
              activeTab === "tab-2"
                ? "tab-switch-button-active"
                : "tab-switch-button"
            }
            onClick={() => setActiveTab("tab-2")}
          >
            My Project
          </button>
          <button
            className={
              activeTab === "tab-3"
                ? "tab-switch-button-active"
                : "tab-switch-button"
            }
            onClick={() => setActiveTab("tab-3")}
          >
            Orders
          </button>
        </div>
        {/* Controller button for the tab management */}
        {/*  */}
        {/* body of the tab which is currenlty selected */}
        {/*  */}

        <div className="tab-content">
          {activeTab === "tab-1" && (
            <div className="wrapper-flex">
              <TrendingCarousel cardDetailsList={cardDetailsList} />

              <TrendingTopicCarousel
                CatergoryCardDetails={categoryCardDetailsList}
              />
            </div>
          )}
          {/* replace from this for tab 2 and 3 */}
          {activeTab === "tab-2" && <div>Content for Tab 2</div>}
          {activeTab === "tab-3" && <div>Content for Tab 3</div>}
        </div>
      </div>
    </div>
  );
};

export default HomePage;
//
//
// data received form the api response
import profilePicture from "./../HomePage/assets/dummy-profile.png";
import TrendingTopicCarousel from "./components/explore-tab/trending-topic-carousel/trendint_topic_carousel";

//simulated as api res create a model and replace it see down too
// for nav bar
const gmail = "Soundhar@gmail.com";
const notificationBadge = true;
const profileUrl = profilePicture;
const userName = "Soundhar_17";

// simulated api res for carousel card trending feelancers
class CardDetails {
  imgUrl!: string;
  name!: string;
  rating!: number;
  ratingCount!: number;
  description!: string;
  price: number = 0;
  profileUrl!: string;
}
//example data replace this with the api
const cardDetailsList: CardDetails[] = [
  {
    imgUrl: "/images_for_trending_freelancer_carousel/tts (1).png",
    name: "Alice Johnson",
    rating: 4.9,
    ratingCount: 250,
    description:
      "UI/UX Designer with a passion for creating beautiful and functional interfaces.",
    price: 3000,
    profileUrl: "https://example.com/profile/alice-johnson",
  },
  {
    imgUrl: "/images_for_trending_freelancer_carousel/tts (2).png",
    name: "Bob Smith",
    rating: 4.7,
    ratingCount: 150,
    description: "Full Stack Developer specializing in React and Node.js.",
    price: 4500,
    profileUrl: "https://example.com/profile/bob-smith",
  },
  {
    imgUrl: "/images_for_trending_freelancer_carousel/tts (3).png",
    name: "Charlie Brown",
    rating: 4.8,
    ratingCount: 200,
    description:
      "Graphic Designer with experience in branding and digital illustration.",
    price: 2500,
    profileUrl: "https://example.com/profile/charlie-brown",
  },
  {
    imgUrl: "/images_for_trending_freelancer_carousel/tts (4).png",
    name: "Diana Prince",
    rating: 4.6,
    ratingCount: 180,
    description:
      "Marketing Specialist with a focus on digital strategies and SEO.",
    price: 3500,
    profileUrl: "https://example.com/profile/diana-prince",
  },
  {
    imgUrl: "/images_for_trending_freelancer_carousel/tts (1).png",
    name: "Alice Johnson",
    rating: 4.9,
    ratingCount: 250,
    description:
      "UI/UX Designer with a passion for creating beautiful and functional interfaces.",
    price: 3000,
    profileUrl: "https://example.com/profile/alice-johnson",
  },
  {
    imgUrl: "/images_for_trending_freelancer_carousel/tts (2).png",
    name: "Bob Smith",
    rating: 4.7,
    ratingCount: 150,
    description: "Full Stack Developer specializing in React and Node.js.",
    price: 4500,
    profileUrl: "https://example.com/profile/bob-smith",
  },
  {
    imgUrl: "/images_for_trending_freelancer_carousel/tts (3).png",
    name: "Charlie Brown",
    rating: 4.8,
    ratingCount: 200,
    description:
      "Graphic Designer with experience in branding and digital illustration.",
    price: 2500,
    profileUrl: "https://example.com/profile/charlie-brown",
  },
  {
    imgUrl: "/images_for_trending_freelancer_carousel/tts (4).png",
    name: "Diana Prince",
    rating: 4.6,
    ratingCount: 180,
    description:
      "Marketing Specialist with a focus on digital strategies and SEO.",
    price: 3500,
    profileUrl: "https://example.com/profile/diana-prince",
  },
];
//
//
//
//
//
///
///
///
///
class CatergoryCardDetails {
  imgUrl!: string;
  title!: string;
  description!: string;
}

const categoryCardDetailsList: CatergoryCardDetails[] = [
  {
    imgUrl: "/image_for_trending_caterogies/group (1).svg",
    title: "Web Development",
    description: "The main role is to develop unique websites.",
  },
  {
    imgUrl: "/image_for_trending_caterogies/group (2).svg",
    title: "Logo Creation",
    description: "The main role is to create unique logos for your business.",
  },
  {
    imgUrl: "/image_for_trending_caterogies/group (3).svg",
    title: "Social Media Marketing",
    description: "The main role is to advertise your product or business.",
  },
  {
    imgUrl: "/image_for_trending_caterogies/group (4).svg",
    title: "Search Engine Optimisation",
    description: "The main role is to build a search engine related to jobs.",
  },
  {
    imgUrl: "/image_for_trending_caterogies/group (5).png",
    title: "Web Development",
    description: "I will design unique websites for your business.",
  },
];
