import React from "react";
import "./../../home-page.css";
import "./nav_bar.css";
// importing assets
import logo from "./../../assets/app-logo.svg";
import bellIcon from "./../../assets/bell.svg";
import bellDotIcon from "./../../assets/bell-on.svg";
import messageIcon from "./../../assets/message-icon.svg";

interface NavBarProps {
  userName: string;
  gmail: string;
  notificationBadge: boolean;
  //   using string temporarily use url in future niggers
  profileUrl: string;
}
//desctructuring and ensuring type safety for thee props
const NavBar: React.FC<NavBarProps> = ({
  userName,
  gmail,
  notificationBadge,
  profileUrl,
}) => {
  return (
    // main element navigation bar
    <header className="navigation-bar">
      {/* logo */}
      <img src={logo} alt="H-Square" />
      {/* right side action buttons container */}
      <div className="action-buttons-container">
        <img
          src={notificationBadge ? bellDotIcon : bellIcon}
          alt="Notifications"
        />
        <img src={messageIcon} alt="Messages" />
        {/* profile picture section */}
        <div className="profile-container">
          <div
            className="profile-picture-container"
            style={{
              background: `url(${profileUrl}) lightgray 50% / cover no-repeat`,
            }}
          >
            {/* <img src={profilePicture} alt="Messages" /> */}
          </div>

          <div className="user-details-container">
            <h2 style={{ lineHeight: "normal", color: "#404145" }}>
              {userName}
            </h2>
            <h4
              style={{
                lineHeight: "normal",
                color: "rgba(64, 65, 69, 0.80)",
              }}
            >
              {gmail}
            </h4>
          </div>
        </div>
      </div>
    </header>
  );
};

export default NavBar;
