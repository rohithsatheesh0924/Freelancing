import React from "react";
import "./search_container.css";
import backgroundImage from "./../../assets/search-container-bg.jpg";
import searchIcon from "./../../assets/search-icon.svg";

interface SearchContainerProps {}

const SearchContainer: React.FC<SearchContainerProps> = () => {
  return (
    // main container for the search
    <div
      className="search-container"
      style={{
        background: `url(${backgroundImage}) lightgray 50% / cover no-repeat`,
      }}
    >
      {/* content insisde the container */}
      {/* hero text */}
      <h1>
        Unlock Talent, <span className="unleash-text-decor">Unleash</span>{" "}
        Potential <br />
        Find Your Perfect Fit
      </h1>
      {/* search box */}
      <form className="search-bar">
        <input
          type="text"
          className="search-input"
          placeholder="Search for services"
        />
        <button className="search-button" type="submit">
          <img src={searchIcon} alt="search" />
        </button>
      </form>
    </div>
  );
};

export default SearchContainer;
