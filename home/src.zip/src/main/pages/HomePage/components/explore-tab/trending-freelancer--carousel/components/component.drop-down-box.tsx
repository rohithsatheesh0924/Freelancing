import React, { useState } from "react";
// import arrowDouble from "./../../../assets/arrow-sort.svg";

const MyDropdown: React.FC = () => {
  const [selectedOption, setSelectedOption] =
    useState<string>("Select an option");

  const handleOptionChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedOption(event.target.value);
  };

  return (
    <div>
      <select
        value={selectedOption}
        onChange={handleOptionChange}
        style={{
          height: "47px",
          padding: "8px 12px",
          borderRadius: "9px",
          backgroundColor: "#ffffff",
          border: "2px solid #EFEFF0",
          color: "color: rgba(64, 65, 69, 0.80)",
          fontFamily: "Poppins",
          fontSize: "14px",
          fontStyle: "normal",
          fontWeight: "500",
        }}
      >
        <option value="Option 1">Web-developement</option>
        <option value="Option 2">App-developement</option>
        <option value="Option 3">Logo creation</option>
        {/* <span
        style={{
          position: "absolute",
          right: "10px",
          top: "50%",
          transform: "translateY(-50%)",
          pointerEvents: "none",
          fontSize: "18px",
          color: "#333",
        }}
      >
        <img src={arrowDouble} alt="" />
      </span> */}
      </select>
    </div>
  );
};

export default MyDropdown;
