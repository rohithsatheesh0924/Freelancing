import React from "react";
import "./../../../home-page.css";
import "./trending_freelancer_carousel.css";
import MyDropdown from "./components/component.drop-down-box";
import TfCard from "./components/component.card";

// Define the CardDetails type
class CardDetails {
  imgUrl!: string;
  name!: string;
  rating!: number;
  ratingCount!: number;
  description!: string;
  price!: number;
  profileUrl!: string;
}

// Define the props interface
interface TrendingCarouselProps {
  cardDetailsList: CardDetails[]; // Use the correct type for arrays
}

// Component definition
const TrendingCarousel: React.FC<TrendingCarouselProps> = ({
  cardDetailsList,
}) => {
  return (
    <div className="trending-carousel-container">
      <h2 style={{ color: "#404145" }}>Trending Freelancers</h2>
      <MyDropdown />
      <div className="scroll-container">
        <div className="sliding-carousel">
          {cardDetailsList.map((cardDetails, index) => (
            <TfCard
              key={index} // Provide a unique key for each item
              cardDetails={cardDetails}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default TrendingCarousel;
