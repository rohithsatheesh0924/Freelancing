import React from "react";
import starIcon from "./../../../../assets/images_for_trending_freelancer_carousel/star.svg";
import rightArrow from "./../../../../assets/images_for_trending_freelancer_carousel/right-arrow.svg";

//model for the data
//put in seperate folder later
class CardDetails {
  imgUrl!: string;
  name!: string;
  rating!: number;
  ratingCount!: number;
  description!: string;
  price!: number;
  profileUrl!: string;
}
interface TfCardProps {
  key: number;
  cardDetails: CardDetails;
}

const TfCard: React.FC<TfCardProps> = ({ cardDetails }) => {
  return (
    <div className="ttc-card">
      <img
        src={cardDetails.imgUrl}
        alt="freelancer-profile"
        style={{ borderRadius: "10px" }}
      />
      <div className="name-and-rating-row">
        <h4>{cardDetails.name}</h4>
        <div className="rating-row">
          <img src={starIcon} alt="rating-icon" />
          <h4>{cardDetails.rating}</h4>
          <h4>{`(${cardDetails.ratingCount})`}</h4>
        </div>
      </div>
      <div className="description">{cardDetails.description}</div>

      <div className="price-and-button-row">
        Starts from ₹{cardDetails.price}
        <button className="my-button" type="submit">
          <img src={rightArrow} alt="right-arrow" />
        </button>
      </div>
    </div>
  );
};

export default TfCard;
