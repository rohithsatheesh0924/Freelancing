import React from "react";
import "./../../../home-page.css";
import "./trending_topic_carousel.css";
import Card from "./component.card";

// Define the CardDetails type
class CatergoryCardDetails {
  imgUrl!: string;
  title!: string;
  description!: string;
}

// Define the props interface
interface TrendingCatergoryCarouselProps {
  CatergoryCardDetails: CatergoryCardDetails[]; // Use the correct type for arrays
}

// Component definition
const TrendingTopicCarousel: React.FC<TrendingCatergoryCarouselProps> = ({
  CatergoryCardDetails,
}) => {
  return (
    <div className="trending-carousel-container">
      <h2 style={{ color: "#404145" }}>Trending Catergories</h2>

      <div className="sliding-carousel">
        {CatergoryCardDetails.map((CatergoryCardDetails, index) => (
          <Card
            key={index} // Provide a unique key for each item
            CatergoryCardDetails={CatergoryCardDetails}
          />
        ))}
      </div>
    </div>
  );
};

export default TrendingTopicCarousel;
