import React from "react";
import "./../../../home-page.css";
import "./trending_topic_carousel.css";
class CatergoryCardDetails {
  imgUrl!: string;
  title!: string;
  description!: string;
}
interface CardProps {
  CatergoryCardDetails: CatergoryCardDetails;
}

const Card: React.FC<CardProps> = ({ CatergoryCardDetails }) => {
  return (
    <div className="catergory-card">
      <img
        src={CatergoryCardDetails.imgUrl}
        alt=""
        style={{ borderRadius: "10px", height: "120px", width: "250px" }}
      />
      <p className="desc" style={{ width: "250px" }}>
        {CatergoryCardDetails.title}
      </p>
      <h4 className="subtitle" style={{ width: "250px" }}>
        {CatergoryCardDetails.description}
      </h4>
    </div>
  );
};

export default Card;
